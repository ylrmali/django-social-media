const likeCount = document.getElementById('likeCount');

likeCount.addEventListener('click',()=>{
    setInterval(function (){

    },10);
});
